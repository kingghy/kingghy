#!/bin/bash
# -*- coding: UTF-8 -*-

python3 /path/Bangumi_Auto_Rename/rename_qb.py