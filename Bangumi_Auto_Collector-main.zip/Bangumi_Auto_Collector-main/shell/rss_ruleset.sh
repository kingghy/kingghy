#!/bin/bash
# -*- coding: UTF-8 -*-

bangumi_name=$1

python3 /path/rule_set.py --name $bangumi_name
